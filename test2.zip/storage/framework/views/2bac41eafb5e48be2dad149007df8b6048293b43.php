<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Prescription</title>
    <style>
        @media  print {
            .m-0 {
                margin: 0;
            }

            .p-0 {
                padding: 0;
            }
  .font1 {
    font-size: 1rem;
  }
  .font2 {
    font-size: 2rem;
  }

        }
        @page  {
    size: 7in 9.25in;
    margin: 27mm 16mm 27mm 16mm;
}
        html,body{
    height:297mm;
    width:210mm;
}

    </style>
</head>

<body>
    <div class="row ">
    <div class="col-12">
 <img src="<?php echo e(asset('header_image.jpg')); ?>"/>
        </div>
        <div class="col-12">
            <div class=" container d-flex justify-content-between">
                <div class="col-3"><p class="font2"> name: <?php echo e($prescription->patient->name); ?></p> </div>
                <?php
                $date = new DateTime($prescription->patient->birth_date);
                $now = new DateTime();
                $age = $now->diff($date)->y;
                ?>

                <div class="col-3"><p class="font2">age: <?php echo e($age); ?></p> </div>
                <div class="col-3"> <p class="font2">sex: <?php echo e($prescription->patient->sex); ?></p></div>
                <div class="col-3"> <p class="font2">date:<?php echo e($prescription->created_at); ?></p> </div>
            </div>

        </div>
        <div class="col-6">

            <div class="container">
                <h3 class="">CC:</h3>
                <?php $__currentLoopData = $prescription->cc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font1"><?php echo e($cc->name); ?>: <?php echo e($cc->value); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="container">
                <h3 class="">Drug History</h3>

                <p class=""><?php echo e($prescription->drug_history); ?></p>

            </div>
            <div class="container">
                <h3 class="">O/E:</h3>
                <?php $__currentLoopData = $prescription->oe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font1"><?php echo e($oe->name); ?>: <?php echo e($oe->value); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="container">
                <h3 class="">Investigations:</h3>
                <?php $__currentLoopData = $prescription->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class=""><?php echo e($tests->name); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            


                <div class="container">
                <h3 class="">Past Medical History</h3>
                <?php if($prescription->medical_history): ?>
                    <?php
                        $medical_history = json_decode($prescription->medical_history);
                    ?>


  <?php
    $showDeasesCollection =  collect($medical_history->diseases);
    $showDeases =   $showDeasesCollection->contains("checked",true);
  ?>
<?php if($showDeases): ?>
<p class="">

<div class="row container">
   <?php $__currentLoopData = $medical_history->diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diseases): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if($diseases->checked): ?>
           <div className="col-6">
               <div className="form-check">
                   <input className="form-check-input" type="checkbox" name="female" checked />

                   <label className="form-check-label">

                       <?php echo e($diseases->name); ?>

                   </label>
               </div>
           </div>
       <?php endif; ?>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


</p>
<?php endif; ?>




















                <?php endif; ?>






            </div>


        </div>
        <div class="col-6">
            <div class="container">
                <h3 class="">Medicines:</h3>
                <div class="row ">
                    <?php $__currentLoopData = $prescription->medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4 text-center">
                            <?php echo e($medicines->product_name); ?>

                        </div>
                        <div class="col-4 text-center">
                            <span class="me-2">

                                <?php echo e($medicines->morning); ?>

                            </span>
                            <span class="me-2">
                                +
                            </span>
                            <span class="me-2">
                                <?php echo e($medicines->afternoon); ?>


                            </span>
                            <span class="me-2">
                                +
                            </span>

                            <span class="me-2">
                                <?php echo e($medicines->night); ?>


                            </span>

                        </div>
                        <div class="col-4 text-center">
                            <?php echo e($medicines->end_time); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH /home/rifat/diagnostic-laravel/resources/views/prescription/invoice.blade.php ENDPATH**/ ?>